package BlockPuzzleLab;

public class PieceState {

    public static PieceState IN_PALETTE;
    public static PieceState IN_PLAY;
    public static PieceState PLACED;


}
