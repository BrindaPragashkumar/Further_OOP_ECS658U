package BlockPuzzleLab;

public enum RegionType {
    //define an enum class for the region types of row,column,sub-square and Piece
        ROW,COLUMN,SUBSQUARE,  PIECE

}
