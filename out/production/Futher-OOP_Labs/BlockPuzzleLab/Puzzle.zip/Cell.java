package BlockPuzzleLab;

import java.awt.*;
import java.awt.geom.Point2D;

public record Cell(int x, int y) {


}

